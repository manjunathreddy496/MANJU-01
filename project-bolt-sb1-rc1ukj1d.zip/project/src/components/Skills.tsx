import React from 'react';
import { 
  Code, 
  Database, 
  Globe, 
  Smartphone, 
  Server, 
  GitBranch,
  Palette,
  Zap
} from 'lucide-react';

interface Skill {
  name: string;
  icon: React.ReactNode;
  level: number;
  color: string;
}

const Skills: React.FC = () => {
  const skills: Skill[] = [
    { name: 'React', icon: <Code size={32} />, level: 95, color: 'from-blue-500 to-cyan-500' },
    { name: 'TypeScript', icon: <Code size={32} />, level: 90, color: 'from-blue-600 to-blue-800' },
    { name: 'Node.js', icon: <Server size={32} />, level: 88, color: 'from-green-500 to-green-700' },
    { name: 'Python', icon: <Zap size={32} />, level: 85, color: 'from-yellow-500 to-orange-500' },
    { name: 'Database', icon: <Database size={32} />, level: 82, color: 'from-purple-500 to-pink-500' },
    { name: 'Next.js', icon: <Globe size={32} />, level: 88, color: 'from-gray-700 to-gray-900' },
    { name: 'React Native', icon: <Smartphone size={32} />, level: 80, color: 'from-indigo-500 to-purple-600' },
    { name: 'Git', icon: <GitBranch size={32} />, level: 92, color: 'from-orange-500 to-red-500' },
    { name: 'UI/UX', icon: <Palette size={32} />, level: 78, color: 'from-pink-500 to-rose-500' }
  ];

  return (
    <section id="skills" className="py-20 bg-black">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-white mb-4">
            My <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">Skills</span>
          </h2>
          <p className="text-xl text-gray-400 text-center mb-16 max-w-2xl mx-auto">
            A comprehensive set of technologies and tools I use to bring ideas to life
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skills.map((skill, index) => (
              <div 
                key={skill.name}
                className="group relative bg-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-800 hover:border-gray-600 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl bg-gradient-to-r ${skill.color} text-white group-hover:scale-110 transition-transform duration-300`}>
                    {skill.icon}
                  </div>
                  <span className="text-2xl font-bold text-gray-400 group-hover:text-white transition-colors duration-300">
                    {skill.level}%
                  </span>
                </div>
                
                <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-blue-400 transition-colors duration-300">
                  {skill.name}
                </h3>
                
                <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
                  <div 
                    className={`h-full bg-gradient-to-r ${skill.color} rounded-full transition-all duration-1000 ease-out`}
                    style={{ width: `${skill.level}%` }}
                  ></div>
                </div>
                
                {/* Hover overlay effect */}
                <div className={`absolute inset-0 bg-gradient-to-r ${skill.color} rounded-2xl opacity-0 group-hover:opacity-5 transition-opacity duration-300`}></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;