import React from 'react';
import { Code, Coffee, Heart } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center text-white mb-12">
            About <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">Me</span>
          </h2>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <p className="text-lg text-gray-300 leading-relaxed">
                I'm a dedicated full-stack developer with over 5 years of experience creating responsive and user-friendly web applications. My passion lies in building digital solutions that make a real impact.
              </p>
              
              <p className="text-lg text-gray-300 leading-relaxed">
                I specialize in modern JavaScript frameworks like React and Node.js, and I'm always eager to learn new technologies and tackle challenging problems. When I'm not coding, you'll find me exploring the latest tech trends or contributing to open-source projects.
              </p>

              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-2 text-blue-400">
                  <Code size={20} />
                  <span>Clean Code</span>
                </div>
                <div className="flex items-center space-x-2 text-purple-400">
                  <Coffee size={20} />
                  <span>Coffee Lover</span>
                </div>
                <div className="flex items-center space-x-2 text-pink-400">
                  <Heart size={20} />
                  <span>Problem Solver</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 transform hover:scale-105 transition-transform duration-300">
                <div className="bg-gray-800 rounded-xl p-6">
                  <h3 className="text-2xl font-bold text-white mb-4">Quick Stats</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Projects Completed</span>
                      <span className="text-blue-400 font-bold text-xl">50+</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Years Experience</span>
                      <span className="text-purple-400 font-bold text-xl">5+</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Happy Clients</span>
                      <span className="text-green-400 font-bold text-xl">30+</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-300">Coffee Cups</span>
                      <span className="text-yellow-400 font-bold text-xl">∞</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;