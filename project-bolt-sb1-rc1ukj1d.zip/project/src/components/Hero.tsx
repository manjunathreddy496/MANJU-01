import React from 'react';
import { ChevronDown, Github, Linkedin, Mail } from 'lucide-react';

const Hero: React.FC = () => {
  const scrollToProjects = () => {
    const element = document.getElementById('projects');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="min-h-screen flex items-center justify-center relative bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute top-40 left-40 w-80 h-80 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      <div className="container mx-auto px-6 text-center relative z-10">
        <div className="animate-fade-in-up">
          {/* Profile Picture */}
          <div className="relative inline-block mb-8">
            <div className="w-32 h-32 mx-auto bg-gradient-to-r from-blue-500 to-purple-600 rounded-full p-1">
              <div className="w-full h-full bg-gray-800 rounded-full flex items-center justify-center">
                <span className="text-4xl font-bold text-white">AJ</span>
              </div>
            </div>
            <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full border-4 border-gray-900"></div>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-fade-in-up animation-delay-200">
            Hi, I'm <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">Alex</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto animate-fade-in-up animation-delay-400">
            A passionate <span className="text-blue-400 font-semibold">Full Stack Developer</span> crafting beautiful and functional web experiences
          </p>

          {/* Social Links */}
          <div className="flex justify-center space-x-6 mb-8 animate-fade-in-up animation-delay-600">
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" 
               className="group p-3 bg-gray-800/50 rounded-full border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:scale-110">
              <Github size={24} className="text-gray-400 group-hover:text-blue-400 transition-colors duration-300" />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" 
               className="group p-3 bg-gray-800/50 rounded-full border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:scale-110">
              <Linkedin size={24} className="text-gray-400 group-hover:text-blue-400 transition-colors duration-300" />
            </a>
            <a href="mailto:alex@example.com" 
               className="group p-3 bg-gray-800/50 rounded-full border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:scale-110">
              <Mail size={24} className="text-gray-400 group-hover:text-blue-400 transition-colors duration-300" />
            </a>
          </div>

          <button 
            onClick={scrollToProjects}
            className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full text-white font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-2xl animate-fade-in-up animation-delay-800"
          >
            View My Work
            <ChevronDown size={20} className="ml-2 animate-bounce" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;